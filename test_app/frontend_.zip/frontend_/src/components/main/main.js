import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { getBudgetsUser } from '../../actions/budgets';
import WasteMoney from './WasteMoney';

export class Budgets extends Component {
  static propTypes = {
    budgets: PropTypes.array.isRequired,
    next: PropTypes.string.isRequired,
    previous: PropTypes.string.isRequired,
  };

  constructor(props) {
    super(props);
    this.componentDidUpdate = this.componentDidUpdate.bind(this);
  }


  componentDidMount() {
    this.props.getBudgetsUser('');
    //this.props.getWasteMoney("", this.props.budgets[0].id)
    // this.props.getWasteMoney("", );
  }

  componentDidUpdate(prevProps) {
    // Typical usage (don't forget to compare props):
    if (this.props.userID !== prevProps.userID) {
      this.props.getBudgetsUser(this.props.next);
    }
  }

  get_next_budget = () => {
    this.props.getBudgetsUser(this.props.next);
    this.render()
  }

  get_prev_budget = () => {
    this.props.getBudgetsUser(this.props.previous);
    this.render();
  }


  render() {
    return (
      <Fragment>
        <h2>Waste money</h2>
          {this.props.budgets.map((budget) => (
            <div class="row">
              <div class="sm-4">
                <div class="card-body">
                  <h5 class="card-title">{budget.name}</h5>
                  <p class="card-text">Баланс: {budget.balance}</p>
                </div>
                </div>
              <div class="sm-8"><WasteMoney budget_id={budget.id} /></div>
            </div>
            ))}
        <button type="button" onClick={this.get_prev_budget} class="btn btn-primary">next</button>
        <button type="button" onClick={this.get_next_budget} class="btn btn-primary">prev</button>


      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  budgets: state.budgets.budgets,
  next: state.budgets.next,
  previous: state.budgets.previous,
});

export default connect(mapStateToProps, { getBudgetsUser })(Budgets);