import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { getWasteMoney } from '../../actions/waste_money';


export class WasteMoney extends Component {
  static propTypes = {
    budget_id: PropTypes.number.isRequired,
    next: PropTypes.string.isRequired,
    previous: PropTypes.string.isRequired,
    waste_money: PropTypes.array.isRequired,
    getWasteMoney: PropTypes.func.isRequired,
  };


  componentDidMount() {
    this.props.getWasteMoney("", this.props.budget_id);  
    console.log(this.props.budget_id)  
    //this.props.getWasteMoney("", this.props.budgets[0].id)
    // this.props.getWasteMoney("", );
  }



  render() {
    return (
      <Fragment>

        <ul class="list-group">
        {this.props.waste_money.map((waste_money_elem) => (
            <li class="list-group-item">{waste_money_elem.name} - {waste_money_elem.price}</li>
        ))}
        </ul>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  waste_money: state.waste_money.waste_money,
  next: state.waste_money.next,
  previous: state.waste_money.previous,
  budget_id: state.waste_money.budget_id,
});

export default connect(mapStateToProps, { getWasteMoney })( WasteMoney );