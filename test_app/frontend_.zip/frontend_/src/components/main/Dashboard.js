import React, { Fragment } from 'react';
import Form from './Form';
import Budgets  from './main';
export default function Dashboard() {
  return (
    <Fragment>
      <Budgets />
    </Fragment>
  );
}